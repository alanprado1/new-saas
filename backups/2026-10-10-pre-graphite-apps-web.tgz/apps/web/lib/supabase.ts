/**
 * lib/supabase.ts
 * ─────────────────────────────────────────────────────────────
 * Single source-of-truth for the browser-side Supabase client.
 * Import { supabase } anywhere in the app — never call createClient again.
 *
 * NOTE: This file must stay in /lib (not /app) so it can be imported by
 * both Server Components (layouts) and Client Components alike.
 */

import { createClient } from "@/utils/supabase/client";

export const supabase = createClient();

/**
 * ensureSession
 * ─────────────────────────────────────────────────────────────
 * Ensures a valid Supabase session exists before making authenticated requests.
 * Call this once on app bootstrap (in layout or page useEffect).
 */
export async function ensureSession(): Promise<void> {
  const { data: { session } } = await supabase.auth.getSession();
  if (!session) {
    throw new Error("Authentication required.");
  }
}
